interface State

class StateTrue : State

class StateFalse : State