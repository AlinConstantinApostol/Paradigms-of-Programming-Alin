# import os
# import sys
# from PyQt5.QtWidgets import QWidget, QApplication, QFileDialog
# from PyQt5.uic import loadUi
# from PyQt5 import QtCore
#
# import sysv_ipc
#
#
#
#
#
#
# def debug_trace(ui=None):
#     from pdb import set_trace
#     QtCore.pyqtRemoveInputHook()
#     set_trace()
#     # QtCore.pyqtRestoreInputHook()
#
#
# def convert_to_html(text):
#     aux = """<!DOCTYPE html>
#     <html lang="en">
#     <head>
#         <title>HTML Converter</title>
#     </head>
#     <body>\n"""
#     for line in text.splitlines():
#         if line.isupper():
#             aux += "\t\t<h1>" + line + "</h1>\n"
#         else:
#             aux += "\t\t<p>" + line + "</p>\n"
#     aux += "\t</body>\n</html>\n"
#     html_file = open("index.html", 'w')
#     html_file.write(aux)
#     return aux
#
#
# class HTMLConverter(QWidget):
#     ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
#
#     def __init__(self):
#         super(HTMLConverter, self).__init__()
#         ui_path = os.path.join(self.ROOT_DIR, 'html_converter.ui')
#         loadUi(ui_path, self)
#         self.browse_btn.clicked.connect(self.browse)
#         self.convert_html.clicked.connect(self.load_file_contents)
#         self.send_to_c.clicked.connect(self.send_to_c_func)
#         self.file_path = None
#
#     def browse(self):
#         options = QFileDialog.Options()
#         options |= QFileDialog.DontUseNativeDialog
#         file, _ = QFileDialog.getOpenFileName(self,
#                                               caption='Select file',
#                                               directory='',
#                                               filter="Text Files (*.txt)",
#                                               options=options)
#         if file:
#             self.file_path = file
#             self.path_line_edit.setText(file)
#             print(file)
#
#     def load_file_contents(self):
#         if self.file_path:
#             try:
#                 with open(self.file_path, 'r') as file:
#                     text = file.read()
#                     html_text = convert_to_html(text)
#                     print(html_text)
#                     self.textOutput.setPlainText(html_text)
#                     return html_text
#
#             except Exception as e:
#                 print("Error:", e)
#
#     def send_to_c_func(self):
#         message = self.load_file_contents()
#         print(message)
#         try:
#             # put the key (integer) as parameter (in this case: -1)
#             message_queue = sysv_ipc.MessageQueue(-1)
#             message
#         except sysv_ipc.ExistentialError:
#             print("Message queue not initialized. Please run the C program first ")
#
#
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     window = HTMLConverter()
#     window.show()
#     sys.exit(app.exec_())
#

import os
import sys
from PyQt5.QtWidgets import QWidget, QApplication, QFileDialog
from PyQt5.uic import loadUi
from PyQt5 import QtCore


def send_message(message_queue, message):
    message_queue.send(message)


def receive_messages(message_queue):
    for item in message_queue.receive():
        if type(item) == bytes:
            print("received: {}".format(item.decode()))


def debug_trace(ui=None):
    from pdb import set_trace
    QtCore.pyqtRemoveInputHook()
    set_trace()
    # QtCore.pyqtRestoreInputHook()


def convert_to_html(text):
    aux = """<!DOCTYPE html>
    <html lang="en">
    <head>
        <title>HTML Converter</title>
    </head>
    <body>\n"""
    for line in text.splitlines():
        if line.isupper():
            aux += "\t\t<h1>" + line + "</h1>\n"
        else:
            aux += "\t\t<p>" + line + "</p>\n"
    aux += "\t</body>\n</html>\n"
    html_file = open("index.html", 'w')
    html_file.write(aux)
    return aux


class HTMLConverter(QWidget):
    ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

    def __init__(self):
        super(HTMLConverter, self).__init__()
        ui_path = os.path.join(self.ROOT_DIR, 'html_converter.ui')
        loadUi(ui_path, self)
        self.browse_btn.clicked.connect(self.browse)
        self.convert_html.clicked.connect(self.load_file_contents)
        self.file_path = None

    def browse(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        file, _ = QFileDialog.getOpenFileName(self,
                                              caption='Select file',
                                              directory='',
                                              filter="Text Files (*.txt)",
                                              options=options)
        if file:
            self.file_path = file
            self.path_line_edit.setText(file)
            print(file)

    def load_file_contents(self):
        if self.file_path:
            try:
                with open(self.file_path, 'r') as file:
                    text = file.read()
                    html_text = convert_to_html(text)
                    print(html_text)
                    self.textOutput.setPlainText(html_text)
            except Exception as e:
                print("Error:", e)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = HTMLConverter()
    window.show()
    sys.exit(app.exec_())
